package net.simplifiedcoding.androidphpmysql;



public class Constants {

   // private static final String ROOT_URL = "http://192.168.1.101/Android/v1/";
  // private static final String ROOT_URL = "http://192.168.1.222/Android/v1/";
    private static final String ROOT_URL = "http://10.250.12.75/Android/v1/";




   // private static final String ROOT_URL = "http://10.0.0.66/Android/v1/";

    public static final String URL_REGISTER = ROOT_URL+"registerUser.php";
    public static final String URL_LOGIN = ROOT_URL+"userLogin.php";


}
